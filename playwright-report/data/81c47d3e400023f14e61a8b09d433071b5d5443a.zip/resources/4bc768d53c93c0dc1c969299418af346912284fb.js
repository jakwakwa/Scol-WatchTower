(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_85fe1b09._.js",
  "static/chunks/_4e27a638._.js"
],
    source: "dynamic"
});
