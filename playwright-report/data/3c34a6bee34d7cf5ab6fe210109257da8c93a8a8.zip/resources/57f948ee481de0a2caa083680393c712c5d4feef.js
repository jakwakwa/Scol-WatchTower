(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/components_4257482f._.js",
  "static/chunks/node_modules_db169bcd._.js"
],
    source: "dynamic"
});
