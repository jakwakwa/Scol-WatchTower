(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__e7ec8358._.css",
  "static/chunks/node_modules_@clerk_nextjs_dist_esm_app-router_5042d62f._.js",
  "static/chunks/node_modules_211dc3f8._.js"
],
    source: "dynamic"
});
