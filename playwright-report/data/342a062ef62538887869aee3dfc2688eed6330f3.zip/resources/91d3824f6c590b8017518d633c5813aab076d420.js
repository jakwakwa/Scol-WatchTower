(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/components_48e1e733._.js",
  "static/chunks/node_modules_2f5b90b3._.js"
],
    source: "dynamic"
});
